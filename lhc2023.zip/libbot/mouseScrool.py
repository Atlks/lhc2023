import sys


# --------------- invk in js------
sys.path.append('D:\\python_module')
sys.path.append('C:\\Users\\attil\\AppData\\Local\\Programs\\Python\\Python312\\Lib\\site-packages')
sys.path.append('C:\\0prj\\lhc2023\\venv\\Lib\\site-packages')

sys.stdin.reconfigure(encoding='utf-8')
sys.stdout.reconfigure(encoding='utf-8')


import pyautogui

import pyautogui
import time

print(sys.argv[1])    #  //prt param  aaa
# pyautogui.scroll(-999)  //down

#pyautogui.scroll(sys.argv[1])


# pyautogui.moveTo(300,500)
# abt 50just one line
pyautogui.scroll(-50*50)
