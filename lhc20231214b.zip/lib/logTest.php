<?php

$GLOBALS['reqchain']="rcv125";
include_once "iniAutoload.php";
include_once "logx.php";
\log_setReqChainLog_enterMeth("METH",123);