<?php


/*
 * todo todo useage...
 * @todo dododoo
 * // todo:: fdafdf
 *
 * */
function ffff356()
{

}