url = "https: //game.gq1sx.cc/index.php?s=handle2/index"

console.log(encodeURIComponent(url))

console.log(999)
    //C: \modyfing\ jbbot\ test\ url.js