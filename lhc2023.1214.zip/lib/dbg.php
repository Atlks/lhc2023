<?php



用 show_source()、highlight_string() 或者 highlight_file() 