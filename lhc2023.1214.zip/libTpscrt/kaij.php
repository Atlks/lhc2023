<?php



 //createTrendImageV2(11);

echo "fini";
