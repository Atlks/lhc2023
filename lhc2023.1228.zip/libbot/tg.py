import sys

import pyautogui
import time

# print(sys.argv[1])     //prt param  aaa
# pyautogui.scroll(-999)  //down


time.sleep(5)

# pyautogui.moveTo(300,500)
# abt 50just one line
pyautogui.scroll(-50*5)