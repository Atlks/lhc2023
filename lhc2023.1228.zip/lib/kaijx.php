<?php
//require_once __DIR__."/../app/common/lotrySscV2.php";
//require __DIR__."/iniAutoload.php";
////echo \kaijx:: kaij_echo("12345");
//// 开奖工具类 for kaij echo
//class kaijx
//{
//
//
////    static function kaij_echo_x($kaijNum)
////    {
////        try {
////            return kaij_echo($kaijNum);
////        } catch (\Throwable $e) {
////        }
////    }
//
//
//}