<?php
sleep(1);