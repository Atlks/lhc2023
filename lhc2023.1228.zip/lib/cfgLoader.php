<?php


//require_once  __DIR__."/../config/cfg_". $GLOBALS['cfgOpt'].".php";

