<?php


echo exec ( "nircmd.exe savescreenshot scrsht.png");
