<?php


sleep(5);
echo 555;